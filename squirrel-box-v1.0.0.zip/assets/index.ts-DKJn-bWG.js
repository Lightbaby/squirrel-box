import{s as v,r as X,a as R}from"./ai-B4mPe7rT.js";import{g as q}from"./utils-C-d0L4dY.js";console.log("松鼠收藏夹: Content script loaded");let S=!1,_=null,E=null;v.getReadingMode().then(t=>{S=t,console.log("Reading mode:",S)});chrome.runtime.onMessage.addListener((t,r,n)=>{if(t.type==="READING_MODE_CHANGED"&&(S=t.enabled,console.log("Reading mode changed:",S)),t.type==="PUBLISH_TWEET"&&(j(t.content),n({success:!0})),t.type==="TOGGLE_FLOATING_BUTTON"){const i=t.show;E&&(E.style.display=i?"flex":"none"),console.log("悬浮按钮显示状态:",i?"显示":"隐藏"),n({success:!0})}return!0});function H(){if(document.getElementById("twitter-ai-floating-btn"))return;const t=document.createElement("div");t.id="twitter-ai-floating-btn";const r=chrome.runtime.getURL("icons/logo.png");t.innerHTML=`
    <img src="${r}" width="40" height="40" style="border-radius: 10px; display: block;">
  `,t.style.cssText=`
    position: fixed;
    bottom: 80px;
    right: 30px;
    width: 60px;
    height: 60px;
    border-radius: 16px;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: grab;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    z-index: 10000;
    transition: all 0.3s ease;
    user-select: none;
  `;let n=!1,i=0,l=0,m=0,p=0;t.onmousedown=e=>{n=!0,t.style.cursor="grabbing",t.style.transition="none";const o=t.getBoundingClientRect();i=e.clientX,l=e.clientY,m=o.left,p=o.top,e.preventDefault()},document.onmousemove=e=>{if(!n)return;const o=e.clientX-i,c=e.clientY-l,u=m+o,h=p+c;t.style.left=`${u}px`,t.style.top=`${h}px`,t.style.right="auto",t.style.bottom="auto"},document.onmouseup=e=>{if(!n)return;n=!1,t.style.cursor="grab",t.style.transition="all 0.3s ease";const o=t.getBoundingClientRect(),c=o.left+o.width/2,u=o.top+o.height/2,h=window.innerWidth,d=window.innerHeight,b=c,y=h-c,C=u,k=d-u,f=Math.min(b,y,C,k),s=30;f===b?(t.style.left=`${s}px`,t.style.top=`${Math.max(s,Math.min(o.top,d-o.height-s))}px`):f===y?(t.style.left=`${h-o.width-s}px`,t.style.top=`${Math.max(s,Math.min(o.top,d-o.height-s))}px`):f===C?(t.style.left=`${Math.max(s,Math.min(o.left,h-o.width-s))}px`,t.style.top=`${s}px`):(t.style.left=`${Math.max(s,Math.min(o.left,h-o.width-s))}px`,t.style.top=`${d-o.height-s}px`),t.style.right="auto",t.style.bottom="auto";const T=e.clientX-i,a=e.clientY-l;Math.sqrt(T*T+a*a)<5&&Y()},t.onmouseover=()=>{n||(t.style.transform="scale(1.08) translateY(-2px)",t.style.boxShadow="0 8px 24px rgba(0, 0, 0, 0.4)")},t.onmouseout=()=>{n||(t.style.transform="scale(1) translateY(0)",t.style.boxShadow="0 4px 16px rgba(0, 0, 0, 0.3)")},document.body.appendChild(t),E=t,console.log("Floating button created")}function N(){document.addEventListener("mouseover",t=>{const n=t.target.closest('article[data-testid="tweet"]');n&&(_=n)})}async function Y(){if(!_){x("请先将鼠标悬停在要收藏的推文上");return}try{await z(_),x("✓ 已收藏！")}catch(t){console.error("Failed to collect tweet:",t),x("✗ 收藏失败")}}async function z(t){try{let n=t.querySelector('[data-testid="tweetText"]')?.textContent||"";const i=t.querySelectorAll('img[src*="pbs.twimg.com"]'),l=Array.from(i).map(a=>a.src).filter(a=>a.includes("profile_images")||a.includes("emoji")||a.includes("_normal")||a.includes("_mini")?!1:a.includes("/media/")||a.includes("tweet_video_thumb")||a.includes("ext_tw_video_thumb"));if(!n&&l.length===0)throw new Error("无法提取推文内容（无文字也无图片）");!n&&l.length>0&&(n=`[图片内容，共 ${l.length} 张图片]`);const m=t.querySelector('[data-testid="User-Name"]'),p=m?.querySelector("span")?.textContent||"Unknown";let e="unknown";const o=t.querySelector('a[href^="/"][role="link"]');if(o){const g=(o.getAttribute("href")||"").match(/^\/([^/]+)$/);g&&(e=g[1])}if(e==="unknown"){const a=m?.querySelectorAll("span")||[];for(const g of a){const w=g.textContent||"";if(w.startsWith("@")){e=w.replace("@","");break}}}console.log("提取到的 authorHandle:",e);let c="";const u=t.querySelector('img[src*="profile_images"]');u?.src&&(c=u.src.replace(/_normal\.(jpg|jpeg|png|gif|webp)$/i,".$1")),console.log("提取到的作者头像:",c?"有":"无");const h=t.querySelector('[data-testid="like"]'),d=t.querySelector('[data-testid="retweet"]'),b=t.querySelector('[data-testid="reply"]'),y=a=>{if(!a)return 0;const w=(a.getAttribute("aria-label")||"0").match(/\d+/);return w?parseInt(w[0]):0},C=D(t),k=`https://twitter.com/${e}/status/${C}`,f=await v.getSettings();let s=null;console.log("评论区收集设置:",f?.enableCommentCollection?"已开启":"未开启"),f?.enableCommentCollection&&(console.log("开始收集评论区内容..."),s=P(t,e),console.log("评论区收集完成:",{authorThread:s.authorThread.slice(0,50),commentsCount:s.otherComments.length}));const T={id:q(),tweetId:C,tweetUrl:k,author:p,authorHandle:e,authorAvatar:c||void 0,content:n,platform:"twitter",keywords:[],collectTime:Date.now(),media:l,stats:{likes:y(h),retweets:y(d),replies:y(b)},authorThread:s?.authorThread||void 0,commentHighlights:s?.otherComments.length?s.otherComments.join(`
`):void 0};if(console.log("Collecting tweet:",T),await v.saveTweet(T),f&&f.apiKey)try{let a=n;if(s?.authorThread&&(a=`${n}

【作者补充内容】
${s.authorThread}`),f.enableImageRecognition&&l.length>0){console.log(`图片识别已启用，共 ${l.length} 张图片，开始识别...`);try{const w=l.slice(0,4),$=(await Promise.all(w.map((A,I)=>X(f,A).then(M=>(console.log(`图片 ${I+1}/${w.length} 识别完成`),M)).catch(M=>(console.warn(`图片 ${I+1} 识别失败:`,M),""))))).filter(A=>A).join(`

---

`);$&&(a=`${a}

【图片内容】
${$}`,console.log("图片识别完成，识别出文字:",$.slice(0,100)))}catch(w){console.error("图片识别失败:",w)}}s?.otherComments.length&&(a=`${a}

【评论区观点】
${s.otherComments.join(`
`)}`);const g=await R(f,a);await v.updateTweet(T.id,{summary:g.summary,keywords:g.keywords,sentiment:g.sentiment,category:g.category}),console.log("AI summary completed")}catch(a){console.error("Failed to get AI summary:",a)}}catch(r){throw console.error("Failed to collect tweet:",r),r}}function D(t){const r=t.querySelector('a[href*="/status/"]');if(r){const n=r.getAttribute("href")?.match(/\/status\/(\d+)/);return n?n[1]:q()}return q()}function P(t,r){const n={authorThread:"",otherComments:[]},i=document.querySelectorAll('article[data-testid="tweet"]'),l=[],m=new Set;return i.forEach(p=>{if(p===t)return;let e="";const o=p.querySelector('a[href^="/"][role="link"]');if(o){const d=(o.getAttribute("href")||"").match(/^\/([^/]+)$/);d&&(e=d[1])}if(!e){const d=p.querySelector('[data-testid="User-Name"]')?.querySelectorAll("span")||[];for(const b of d){const y=b.textContent||"";if(y.startsWith("@")){e=y.replace("@","");break}}}const u=p.querySelector('[data-testid="tweetText"]')?.textContent?.trim()||"";if(u){if(e&&e.toLowerCase()===r.toLowerCase())l.push(u);else if(e){const h=u.length>100?u.slice(0,100)+"...":u,d=`@${e}: ${h}`;m.add(d)}}}),n.authorThread=l.join(`

`),n.otherComments=Array.from(m).slice(0,10),n}function x(t){const r=document.createElement("div");r.textContent=t,r.style.cssText=`
    position: fixed;
    top: 80px;
    right: 80px;
    background: #1d9bf0;
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(29, 155, 240, 0.3);
    z-index: 10001;
    font-size: 14px;
    font-weight: 500;
    animation: slideIn 0.3s ease-out;
  `,document.body.appendChild(r),setTimeout(()=>{r.style.animation="slideOut 0.3s ease-out",setTimeout(()=>r.remove(),300)},2e3)}const L=document.createElement("style");L.textContent=`
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
`;document.head.appendChild(L);async function j(t){try{const r=document.querySelector('[data-testid="SideNav_NewTweet_Button"]');r&&(r.click(),await new Promise(e=>setTimeout(e,1e3)));const n=document.querySelector('[data-testid="tweetTextarea_0"]');if(!n)throw new Error("无法找到发推文本框，请确保已打开 Twitter/X 页面");try{await navigator.clipboard.writeText(t)}catch{}n.focus(),await new Promise(e=>setTimeout(e,100));const i=n.querySelector('[contenteditable="true"]')||n.closest('[contenteditable="true"]')||n;i instanceof HTMLElement&&i.focus();const l=window.getSelection();if(l&&l.removeAllRanges(),i instanceof HTMLElement){const e=document.createRange();e.selectNodeContents(i),e.collapse(!0),l?.addRange(e)}const m=t.split(`
`);for(let e=0;e<m.length;e++){const o=m[e];if(o&&(document.execCommand("insertText",!1,o)||i.dispatchEvent(new InputEvent("beforeinput",{inputType:"insertText",data:o,bubbles:!0,cancelable:!0}))),e<m.length-1){i.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0,cancelable:!0}));let c=document.execCommand("insertParagraph",!1);c||(c=document.execCommand("insertLineBreak",!1)),c||i.dispatchEvent(new InputEvent("beforeinput",{inputType:"insertParagraph",bubbles:!0,cancelable:!0})),i.dispatchEvent(new KeyboardEvent("keyup",{key:"Enter",code:"Enter",keyCode:13,which:13,bubbles:!0,cancelable:!0}))}await new Promise(c=>setTimeout(c,20))}i.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0})),i.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0})),await new Promise(e=>setTimeout(e,200)),(i.textContent||"").length<t.length/3?x("📋 内容已复制！请按 Ctrl+V (Mac: Cmd+V) 粘贴"):x("✓ 内容已填入，请检查后点击发布")}catch(r){console.error("Failed to publish tweet:",r);try{await navigator.clipboard.writeText(t),x("📋 内容已复制！请按 Ctrl+V 粘贴到输入框")}catch{x("✗ 发布失败："+(r instanceof Error?r.message:"未知错误"))}}}async function B(){console.log("Initializing 松鼠收藏夹...");const r=(await v.getSettings())?.showFloatingButton!==!1;H(),N(),E&&!r&&(E.style.display="none",console.log("悬浮按钮已根据设置隐藏")),console.log("松鼠收藏夹 initialized!")}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",B):B();
