import{s as S,r as L,a as N}from"./ai-B4mPe7rT.js";import{g as X}from"./utils-C-d0L4dY.js";console.log("松鼠收藏夹 (小红书): Content script loaded");let A=!1,M=null;S.getReadingMode().then(t=>{A=t,console.log("Reading mode:",A)});chrome.runtime.onMessage.addListener((t,o,a)=>(t.type==="READING_MODE_CHANGED"&&(A=t.enabled,console.log("Reading mode changed:",A)),t.type==="PUBLISH_TWEET"&&a({success:!1,message:"小红书发布功能开发中"}),!0));function U(){if(document.getElementById("twitter-ai-floating-btn"))return;const t=document.createElement("div");t.id="twitter-ai-floating-btn";const o=chrome.runtime.getURL("icons/logo.png");t.innerHTML=`
    <img src="${o}" width="40" height="40" style="border-radius: 10px; display: block;">
  `,t.style.cssText=`
    position: fixed;
    bottom: 80px;
    right: 30px;
    width: 60px;
    height: 60px;
    border-radius: 16px;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: grab;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    z-index: 10000;
    transition: all 0.3s ease;
    user-select: none;
  `;let a=!1,p=0,y=0,g=0,i=0;t.onmousedown=r=>{a=!0,t.style.cursor="grabbing",t.style.transition="none";const e=t.getBoundingClientRect();p=r.clientX,y=r.clientY,g=e.left,i=e.top,r.preventDefault()},document.onmousemove=r=>{if(!a)return;const e=r.clientX-p,f=r.clientY-y,l=g+e,u=i+f;t.style.left=`${l}px`,t.style.top=`${u}px`,t.style.right="auto",t.style.bottom="auto"},document.onmouseup=r=>{if(!a)return;a=!1,t.style.cursor="grab",t.style.transition="all 0.3s ease";const e=t.getBoundingClientRect(),f=e.left+e.width/2,l=e.top+e.height/2,u=window.innerWidth,m=window.innerHeight,c=f,w=u-f,b=l,$=m-l,x=Math.min(c,w,b,$),s=30;x===c?(t.style.left=`${s}px`,t.style.top=`${Math.max(s,Math.min(e.top,m-e.height-s))}px`):x===w?(t.style.left=`${u-e.width-s}px`,t.style.top=`${Math.max(s,Math.min(e.top,m-e.height-s))}px`):x===b?(t.style.left=`${Math.max(s,Math.min(e.left,u-e.width-s))}px`,t.style.top=`${s}px`):(t.style.left=`${Math.max(s,Math.min(e.left,u-e.width-s))}px`,t.style.top=`${m-e.height-s}px`),t.style.right="auto",t.style.bottom="auto";const d=r.clientX-p,C=r.clientY-y;Math.sqrt(d*d+C*C)<5&&D()},t.onmouseover=()=>{a||(t.style.transform="scale(1.08) translateY(-2px)",t.style.boxShadow="0 8px 24px rgba(0, 0, 0, 0.4)")},t.onmouseout=()=>{a||(t.style.transform="scale(1) translateY(0)",t.style.boxShadow="0 4px 16px rgba(0, 0, 0, 0.3)")},document.body.appendChild(t),console.log("Floating button created")}function Y(){document.addEventListener("mouseover",t=>{const a=t.target.closest('.note-item, [class*="note"], [class*="card"]');a&&(M=a)})}async function D(){if(!M){E("请先将鼠标悬停在要收藏的笔记上");return}try{await j(M),E("✓ 已收藏！")}catch(t){console.error("Failed to collect note:",t),E("✗ 收藏失败")}}async function j(t){try{const o=t.querySelector('.note-title, [class*="title"]'),a=t.querySelector('.note-content, [class*="desc"], [class*="content"]'),p=t.querySelector('.author-name, [class*="author"], [class*="name"]'),y=o?.textContent?.trim()||"",g=a?.textContent?.trim()||"",i=y?`${y}

${g}`:g;if(!i)throw new Error("无法提取笔记内容");let r=p?.textContent?.trim()||"Unknown";r=r.replace(/关注$/,"").replace(/已关注$/,"").replace(/\s*关注\s*$/,"").trim();const e=t.querySelector('a[href*="/user/profile/"]');let f="",l="";if(e){const n=e.getAttribute("href")||"";f=n.startsWith("http")?n:`https://www.xiaohongshu.com${n}`;const h=f.match(/\/user\/profile\/([a-zA-Z0-9]+)/);l=h?h[1]:""}let u="";const m=[".author-avatar img",".avatar img",'[class*="avatar"] img','a[href*="/user/profile/"] img'];for(const n of m){const h=t.querySelector(n);if(h?.src&&h.src.includes("sns-avatar")){u=h.src;break}}console.log("提取到的作者头像:",u?"有":"无");const c=t.querySelector('a[href*="/explore/"]');let w=c?new URL(c.getAttribute("href")||"",window.location.origin).href:window.location.href;w=H(w);const b=t.querySelectorAll("img[src]"),$=new Set;Array.from(b).map(n=>n.src).filter(n=>!n||n.includes("avatar")||n.includes("picasso-static")||n.includes("emoji")||n.includes("icon")||n.includes("/fe-platform/")?!1:n.includes("sns-webpic")||n.includes("xhscdn.com")).forEach(n=>$.add(n));const x=Array.from($),s=await S.getSettings();let d=null;console.log("评论区收集设置:",s?.enableCommentCollection?"已开启":"未开启"),s?.enableCommentCollection&&(console.log("开始收集评论区内容..."),d=F(r));const C={id:X(),tweetId:B(w),tweetUrl:w,author:r,authorHandle:l||r.toLowerCase().replace(/\s+/g,"_"),authorProfileUrl:f||void 0,authorAvatar:u||void 0,content:i,platform:"xiaohongshu",keywords:[],collectTime:Date.now(),media:x,stats:{likes:0,retweets:0,replies:0},authorThread:d?.authorThread||void 0,commentHighlights:d?.otherComments.length?d.otherComments.join(`
`):void 0};if(console.log("Collecting note:",C),await S.saveTweet(C),s&&s.apiKey)try{let n=i;if(d?.authorThread&&(n=`${i}

【作者补充内容】
${d.authorThread}`),s.enableImageRecognition&&x.length>0){console.log(`图片识别已启用，共 ${x.length} 张图片，开始识别...`);try{const T=x.slice(0,9),v=(await Promise.all(T.map((I,q)=>L(s,I).then(k=>(console.log(`图片 ${q+1}/${T.length} 识别完成`),k)).catch(k=>(console.warn(`图片 ${q+1} 识别失败:`,k),""))))).filter(I=>I).join(`

---

`);v&&(n=`${i}

【图片内容】
${v}`,console.log("图片识别完成，识别出文字:",v.slice(0,100)))}catch(T){console.error("图片识别失败:",T)}}d?.otherComments.length&&(n=`${n}

【评论区观点】
${d.otherComments.join(`
`)}`);const h=await N(s,n);await S.updateTweet(C.id,{summary:h.summary,keywords:h.keywords,sentiment:h.sentiment,category:h.category}),console.log("AI summary completed")}catch(n){console.error("Failed to get AI summary:",n)}}catch(o){throw console.error("Failed to collect note:",o),o}}function B(t){const o=t.match(/\/explore\/([a-zA-Z0-9]+)/);return o?o[1]:X()}function H(t){try{const o=new URL(t);return`${o.origin}${o.pathname}`}catch{return t}}function F(t){const o={authorThread:"",otherComments:[]},a=[],p=new Set,y=[".comment-item",".comments-container .comment",'[class*="comment-item"]','[class*="CommentItem"]',".note-comment"];let g=[];for(const i of y){const r=document.querySelectorAll(i);if(r.length>0){g=Array.from(r),console.log(`找到评论元素: ${i}, 数量: ${r.length}`);break}}return g.length===0?(console.log("未找到评论区元素"),o):(g.forEach(i=>{const r=[".user-name",".author-name",'[class*="nickname"]','[class*="userName"]','[class*="name"]'];let e="";for(const m of r){const c=i.querySelector(m);if(c?.textContent?.trim()){e=c.textContent.trim();break}}const f=[".comment-content",".content",'[class*="content"]','[class*="text"]'];let l="";for(const m of f){const c=i.querySelector(m);if(c?.textContent?.trim()){l=c.textContent.trim();break}}if(!l)return;if(e&&(e===t||i.querySelector('[class*="author-tag"]')||i.querySelector('[class*="作者"]')))a.push(l);else if(e){const m=l.length>100?l.slice(0,100)+"...":l,c=`${e}: ${m}`;p.add(c)}}),o.authorThread=a.join(`

`),o.otherComments=Array.from(p).slice(0,10),console.log("评论区收集结果:",{authorThread:o.authorThread.slice(0,50),commentsCount:o.otherComments.length}),o)}function E(t){const o=document.createElement("div");o.textContent=t,o.style.cssText=`
    position: fixed;
    top: 80px;
    right: 80px;
    background: #1d9bf0;
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(29, 155, 240, 0.3);
    z-index: 10001;
    font-size: 14px;
    font-weight: 500;
    animation: slideIn 0.3s ease-out;
  `,document.body.appendChild(o),setTimeout(()=>{o.style.animation="slideOut 0.3s ease-out",setTimeout(()=>o.remove(),300)},2e3)}const z=document.createElement("style");z.textContent=`
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
`;document.head.appendChild(z);function R(){console.log("Initializing Twitter AI Assistant for 小红书..."),U(),Y(),console.log("Twitter AI Assistant for 小红书 initialized!")}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",R):R();
