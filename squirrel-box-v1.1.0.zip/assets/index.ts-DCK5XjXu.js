import{s as v}from"./storage-CGu7w2p6.js";import{r as P,s as X}from"./ai-Mt35Rsbr.js";import{g as A}from"./utils-C-d0L4dY.js";console.log("松鼠收藏夹: Content script loaded");let _=!1,N=null,$=null,T=!1,D=new Set,k=location.href;chrome.runtime.sendMessage({type:"GET_INSPIRATION_MODE"}).then(t=>{t?.enabled&&(T=!0,console.log("[灵感模式] 已开启"),j())}).catch(()=>{});v.getReadingMode().then(t=>{_=t,console.log("Reading mode:",_)});chrome.runtime.onMessage.addListener((t,o,e)=>{if(t.type==="READING_MODE_CHANGED"&&(_=t.enabled,console.log("Reading mode changed:",_)),t.type==="PUBLISH_TWEET"&&(V(t.content),e({success:!0})),t.type==="TOGGLE_FLOATING_BUTTON"){const i=t.show;$&&($.style.display=i?"flex":"none"),console.log("悬浮按钮显示状态:",i?"显示":"隐藏"),e({success:!0})}if(t.type==="INSPIRATION_MODE_CHANGED"){const i=T;T=t.enabled,console.log("[灵感模式] 状态变化:",T?"开启":"关闭"),T&&!i?j():!T&&i&&K(),e({success:!0})}return!0});function Y(){if(document.getElementById("twitter-ai-floating-btn"))return;const t=document.createElement("div");t.id="twitter-ai-floating-btn";const o=chrome.runtime.getURL("icons/logo.png");t.innerHTML=`
    <img src="${o}" width="40" height="40" style="border-radius: 10px; display: block;">
  `,t.style.cssText=`
    position: fixed;
    bottom: 80px;
    right: 30px;
    width: 60px;
    height: 60px;
    border-radius: 16px;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: grab;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    z-index: 10000;
    transition: all 0.3s ease;
    user-select: none;
  `;let e=!1,i=0,s=0,g=0,m=0;t.onmousedown=r=>{e=!0,t.style.cursor="grabbing",t.style.transition="none";const n=t.getBoundingClientRect();i=r.clientX,s=r.clientY,g=n.left,m=n.top,r.preventDefault()},document.onmousemove=r=>{if(!e)return;const n=r.clientX-i,p=r.clientY-s,u=g+n,h=m+p;t.style.left=`${u}px`,t.style.top=`${h}px`,t.style.right="auto",t.style.bottom="auto"},document.onmouseup=r=>{if(!e)return;e=!1,t.style.cursor="grab",t.style.transition="all 0.3s ease";const n=t.getBoundingClientRect(),p=n.left+n.width/2,u=n.top+n.height/2,h=window.innerWidth,c=window.innerHeight,C=p,d=h-p,y=u,f=c-u,w=Math.min(C,d,y,f),l=30;w===C?(t.style.left=`${l}px`,t.style.top=`${Math.max(l,Math.min(n.top,c-n.height-l))}px`):w===d?(t.style.left=`${h-n.width-l}px`,t.style.top=`${Math.max(l,Math.min(n.top,c-n.height-l))}px`):w===y?(t.style.left=`${Math.max(l,Math.min(n.left,h-n.width-l))}px`,t.style.top=`${l}px`):(t.style.left=`${Math.max(l,Math.min(n.left,h-n.width-l))}px`,t.style.top=`${c-n.height-l}px`),t.style.right="auto",t.style.bottom="auto";const S=r.clientX-i,a=r.clientY-s;Math.sqrt(S*S+a*a)<5&&F()},t.onmouseover=()=>{e||(t.style.transform="scale(1.08) translateY(-2px)",t.style.boxShadow="0 8px 24px rgba(0, 0, 0, 0.4)")},t.onmouseout=()=>{e||(t.style.transform="scale(1) translateY(0)",t.style.boxShadow="0 4px 16px rgba(0, 0, 0, 0.3)")},document.body.appendChild(t),$=t,console.log("Floating button created")}function z(){document.addEventListener("mouseover",t=>{const e=t.target.closest('article[data-testid="tweet"]');e&&(N=e)})}async function F(){if(!N){I("请先将鼠标悬停在要收藏的推文上");return}try{await G(N),I("✓ 已收藏！")}catch(t){console.error("Failed to collect tweet:",t),I("✗ 收藏失败")}}async function G(t){try{let e=t.querySelector('[data-testid="tweetText"]')?.textContent||"";const i=t.querySelectorAll('img[src*="pbs.twimg.com"]'),s=Array.from(i).map(a=>a.src).filter(a=>a.includes("profile_images")||a.includes("emoji")||a.includes("_normal")||a.includes("_mini")?!1:a.includes("/media/")||a.includes("tweet_video_thumb")||a.includes("ext_tw_video_thumb"));if(!e&&s.length===0)throw new Error("无法提取推文内容（无文字也无图片）");!e&&s.length>0&&(e=`[图片内容，共 ${s.length} 张图片]`);const g=t.querySelector('[data-testid="User-Name"]'),m=g?.querySelector("span")?.textContent||"Unknown";let r="unknown";const n=t.querySelector('a[href^="/"][role="link"]');if(n){const x=(n.getAttribute("href")||"").match(/^\/([^/]+)$/);x&&(r=x[1])}if(r==="unknown"){const a=g?.querySelectorAll("span")||[];for(const x of a){const b=x.textContent||"";if(b.startsWith("@")){r=b.replace("@","");break}}}console.log("提取到的 authorHandle:",r);let p="";const u=t.querySelector('img[src*="profile_images"]');u?.src&&(p=u.src.replace(/_normal\.(jpg|jpeg|png|gif|webp)$/i,".$1")),console.log("提取到的作者头像:",p?"有":"无");const h=t.querySelector('[data-testid="like"]'),c=t.querySelector('[data-testid="retweet"]'),C=t.querySelector('[data-testid="reply"]'),d=a=>{if(!a)return 0;const b=(a.getAttribute("aria-label")||"0").match(/\d+/);return b?parseInt(b[0]):0},y=W(t),f=`https://twitter.com/${r}/status/${y}`,w=await v.getSettings();let l=null;console.log("评论区收集设置:",w?.enableCommentCollection?"已开启":"未开启"),w?.enableCommentCollection&&(console.log("开始收集评论区内容..."),l=B(t,r),console.log("评论区收集完成:",{authorThread:l.authorThread.slice(0,50),commentsCount:l.otherComments.length}));const S={id:A(),tweetId:y,tweetUrl:f,author:m,authorHandle:r,authorAvatar:p||void 0,content:e,platform:"twitter",keywords:[],collectTime:Date.now(),media:s,stats:{likes:d(h),retweets:d(c),replies:d(C)},authorThread:l?.authorThread||void 0,commentHighlights:l?.otherComments.length?l.otherComments.join(`
`):void 0};if(console.log("Collecting tweet:",S),await v.saveTweet(S),w&&w.apiKey)try{let a=e;if(l?.authorThread&&(a=`${e}

【作者补充内容】
${l.authorThread}`),w.enableImageRecognition&&s.length>0){console.log(`图片识别已启用，共 ${s.length} 张图片，开始识别...`);try{const b=s.slice(0,4),q=(await Promise.all(b.map((E,O)=>P(w,E).then(M=>(console.log(`图片 ${O+1}/${b.length} 识别完成`),M)).catch(M=>(console.warn(`图片 ${O+1} 识别失败:`,M),""))))).filter(E=>E).join(`

---

`);q&&(a=`${a}

【图片内容】
${q}`,console.log("图片识别完成，识别出文字:",q.slice(0,100)))}catch(b){console.error("图片识别失败:",b)}}l?.otherComments.length&&(a=`${a}

【评论区观点】
${l.otherComments.join(`
`)}`);const x=await X(w,a);await v.updateTweet(S.id,{summary:x.summary,keywords:x.keywords,sentiment:x.sentiment,category:x.category}),console.log("AI summary completed")}catch(a){console.error("Failed to get AI summary:",a)}}catch(o){throw console.error("Failed to collect tweet:",o),o}}function W(t){const o=t.querySelector('a[href*="/status/"]');if(o){const e=o.getAttribute("href")?.match(/\/status\/(\d+)/);return e?e[1]:A()}return A()}function B(t,o){const e={authorThread:"",otherComments:[]},i=document.querySelectorAll('article[data-testid="tweet"]'),s=[],g=new Set;return i.forEach(m=>{if(m===t)return;let r="";const n=m.querySelector('a[href^="/"][role="link"]');if(n){const c=(n.getAttribute("href")||"").match(/^\/([^/]+)$/);c&&(r=c[1])}if(!r){const c=m.querySelector('[data-testid="User-Name"]')?.querySelectorAll("span")||[];for(const C of c){const d=C.textContent||"";if(d.startsWith("@")){r=d.replace("@","");break}}}const u=m.querySelector('[data-testid="tweetText"]')?.textContent?.trim()||"";if(u){if(r&&r.toLowerCase()===o.toLowerCase())s.push(u);else if(r){const h=u.length>100?u.slice(0,100)+"...":u,c=`@${r}: ${h}`;g.add(c)}}}),e.authorThread=s.join(`

`),e.otherComments=Array.from(g).slice(0,10),e}function I(t){const o=document.createElement("div");o.textContent=t,o.style.cssText=`
    position: fixed;
    top: 80px;
    right: 80px;
    background: #1d9bf0;
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(29, 155, 240, 0.3);
    z-index: 10001;
    font-size: 14px;
    font-weight: 500;
    animation: slideIn 0.3s ease-out;
  `,document.body.appendChild(o),setTimeout(()=>{o.style.animation="slideOut 0.3s ease-out",setTimeout(()=>o.remove(),300)},2e3)}const R=document.createElement("style");R.textContent=`
  @keyframes slideIn {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }
`;document.head.appendChild(R);async function V(t){try{const o=document.querySelector('[data-testid="SideNav_NewTweet_Button"]');o&&(o.click(),await new Promise(i=>setTimeout(i,500)));const e=document.querySelector('[data-testid="tweetTextarea_0"]');if(e){const i=e.querySelector('[contenteditable="true"]')||e;i instanceof HTMLElement&&i.focus()}I("📋 内容已复制！请按 Cmd+V 粘贴")}catch(o){console.error("Failed to open compose:",o),I("📋 内容已复制！请按 Cmd+V 粘贴")}}function j(){console.log("[灵感模式] 初始化采集..."),L()?H():Q(),J()}function K(){console.log("[灵感模式] 停止采集")}function L(){return location.pathname.includes("/status/")}function J(){setInterval(()=>{if(location.href!==k){if(k=location.href,console.log("[灵感模式] URL 变化:",k),!T)return;L()&&setTimeout(()=>H(),1e3)}},500)}function Q(){const t=new IntersectionObserver(i=>{T&&i.forEach(s=>{if(s.isIntersecting){const g=s.target;Z(g)}})},{threshold:.5});function o(){document.querySelectorAll('article[data-testid="tweet"]').forEach(s=>{s.hasAttribute("data-inspiration-observed")||(s.setAttribute("data-inspiration-observed","true"),t.observe(s))})}o(),new MutationObserver(()=>{T&&o()}).observe(document.body,{childList:!0,subtree:!0})}function Z(t){try{if(L())return;const o=t.querySelector('a[href*="/status/"]');if(!o)return;const i=(o.getAttribute("href")||"").match(/\/([^/]+)\/status\/(\d+)/);if(!i)return;const s=i[1],g=i[2],m=`https://twitter.com/${s}/status/${g}`;if(D.has(m))return;D.add(m);const n=t.querySelector('[data-testid="User-Name"]')?.querySelector("span")?.textContent||s;let p="";const u=t.querySelector('img[src*="profile_images"]');u?.src&&(p=u.src.replace(/_normal\.(jpg|jpeg|png|gif|webp)$/i,".$1"));const c=t.querySelector('[data-testid="tweetText"]')?.textContent?.trim()||"",d=t.querySelector('img[src*="pbs.twimg.com/media"]')?.src||"";if(!c&&!d)return;const y={id:A(),platform:"twitter",author:n,authorHandle:s,authorAvatar:p||void 0,summary:c?.slice(0,150)||void 0,url:m,thumbnail:d||void 0,capturedAt:Date.now(),isDetail:!1};console.log("[灵感模式] 采集列表项:",y.summary?.slice(0,30)||"[图片]"),chrome.runtime.sendMessage({type:"INSPIRATION_ITEM_CAPTURED",item:y})}catch(o){console.error("[灵感模式] 采集列表项失败:",o)}}async function H(){if(T)try{await new Promise(f=>setTimeout(f,500));const t=document.querySelector('article[data-testid="tweet"]');if(!t){console.log("[灵感模式] 未找到主推文");return}const o=location.pathname.match(/\/([^/]+)\/status\/(\d+)/);if(!o)return;const e=o[1],i=o[2],s=`https://twitter.com/${e}/status/${i}`,m=t.querySelector('[data-testid="User-Name"]')?.querySelector("span")?.textContent||e;let r="";const n=t.querySelector('img[src*="profile_images"]');n?.src&&(r=n.src.replace(/_normal\.(jpg|jpeg|png|gif|webp)$/i,".$1"));const u=t.querySelector('[data-testid="tweetText"]')?.textContent?.trim()||"",h=t.querySelectorAll('img[src*="pbs.twimg.com"]'),c=Array.from(h).map(f=>f.src).filter(f=>f.includes("profile_images")||f.includes("emoji")||f.includes("_normal")||f.includes("_mini")?!1:f.includes("/media/")||f.includes("tweet_video_thumb"));if(!u&&c.length===0){console.log("[灵感模式] 详情页内容为空，跳过");return}const C=await v.getSettings();let d=null;C?.enableCommentCollection&&(d=B(t,e));const y={id:A(),platform:"twitter",author:m,authorHandle:e,authorAvatar:r||void 0,authorProfileUrl:`https://twitter.com/${e}`,content:u||`[图片内容，共 ${c.length} 张]`,url:s,thumbnail:c[0]||void 0,media:c.length>0?c:void 0,capturedAt:Date.now(),isDetail:!0,authorThread:d?.authorThread||void 0,commentHighlights:d?.otherComments.length?d.otherComments.join(`
`):void 0};console.log("[灵感模式] 采集详情页:",y.content?.slice(0,30)),chrome.runtime.sendMessage({type:"INSPIRATION_ITEM_CAPTURED",item:y}),D.add(s)}catch(t){console.error("[灵感模式] 采集详情页失败:",t)}}async function U(){console.log("Initializing 松鼠收藏夹...");const o=(await v.getSettings())?.showFloatingButton!==!1;Y(),z(),$&&!o&&($.style.display="none",console.log("悬浮按钮已根据设置隐藏")),console.log("松鼠收藏夹 initialized!")}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",U):U();
